"""timer"""

# -*- coding:utf-8 -*-

from .timer import timeout, Timeout
