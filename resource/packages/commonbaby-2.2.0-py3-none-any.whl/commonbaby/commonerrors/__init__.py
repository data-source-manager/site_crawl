"""Common exceptions"""

# -*- coding:utf-8 -*-

from .argument_none_error import *

__all__ = ["ArgumentNoneError"]
